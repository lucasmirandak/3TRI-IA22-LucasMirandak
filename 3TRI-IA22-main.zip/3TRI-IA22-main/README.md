# 3TRI-IA22


### Criar novo projeto REACT com Vite

```sh
npm create vite@latest
cd __NOME_DA_PASTA_DO_PROJETO__
npm install
```

### Executar o projeto em tempo de desenvolvimento

```sh
cd __NOME_DA_PASTA_DO_PROJETO__
npm run dev
```